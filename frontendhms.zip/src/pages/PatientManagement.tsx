import React from 'react';
import PatientList from '@/components/Patients/PatientList';

export const PatientManagement: React.FC = () => {
  return <PatientList />;
};

export default PatientManagement;