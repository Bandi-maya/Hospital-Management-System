export default function Payments() {
    return <div className="p-6 space-y-6">
        <div className="flex justify-between items-center">
            <h1 className="text-2xl font-bold">Billing & Invoice</h1>
            <p className="text-muted-foreground">Payments</p>
        </div>
    </div>
}